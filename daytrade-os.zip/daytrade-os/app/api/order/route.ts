import { brokerConfigured, getAccount, isLive, placeBracket } from "@/lib/broker";
import { bySymbol } from "@/lib/instruments";

const MAX_RISK_PCT = 2; // hard server-side ceiling per trade, regardless of what the client sends

export async function POST(req: Request) {
  const b = await req.json().catch(() => null);
  if (!b) return Response.json({ error: "Bad JSON" }, { status: 400 });
  const inst = bySymbol(b.symbol);
  if (!inst || inst.tradable !== "alpaca")
    return Response.json({ error: "This instrument can't be traded through the app (gold spot is copy-to-MT5)." }, { status: 400 });
  if (!brokerConfigured()) return Response.json({ error: "Alpaca keys not configured." }, { status: 400 });

  const qty = Math.floor(Number(b.qty));
  const { entry, stop, target } = b as { entry: number; stop: number; target: number };
  const side = b.side === "short" ? "short" : "long";
  const sane = side === "long" ? stop < entry && entry < target : target < entry && entry < stop;
  if (!(qty >= 1) || !sane) return Response.json({ error: "Invalid quantity or stop/target levels." }, { status: 400 });

  if (isLive() && b.confirmLive !== true)
    return Response.json({ error: "LIVE account: explicit confirmation required." }, { status: 400 });

  try {
    const acct = await getAccount();
    const equity = Number(acct.equity);
    const risk = qty * Math.abs(entry - stop);
    if (risk > equity * (MAX_RISK_PCT / 100))
      return Response.json({ error: `Risk $${risk.toFixed(2)} exceeds the ${MAX_RISK_PCT}% per-trade ceiling.` }, { status: 400 });
    if (qty * entry > Number(acct.buying_power))
      return Response.json({ error: "Not enough buying power." }, { status: 400 });
    const order = await placeBracket({ symbol: inst.symbol, side, qty, stop, target });
    return Response.json({ ok: true, live: isLive(), orderId: order.id, status: order.status });
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 502 });
  }
}
